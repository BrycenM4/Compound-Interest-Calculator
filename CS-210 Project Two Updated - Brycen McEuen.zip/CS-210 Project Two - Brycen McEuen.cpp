// CS-210 Project Two - Brycen McEuen.cpp : This file contains the 'main' function. Program execution begins and ends there.


#include <iostream>
#include <cmath>
#include <iomanip>
#include <vector>
#include "Menu.h" // Include Menu header file to use Menu class

using namespace std;


// Main
int main() {
	Menu app;
	app.run();
	return 0;
}